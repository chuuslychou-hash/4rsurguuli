import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, FileText, Bell, Star, X, Volume2, VolumeX, CheckCircle, Smartphone } from 'lucide-react';
import { collection, query, where, onSnapshot, limit, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { UserData } from './LoginForm';

export interface AppNotification {
  id: string;
  title: string;
  body: string;
  type: 'chat' | 'lesson' | 'assignment' | 'grade' | 'system' | 'award';
  timestamp: Date;
  senderName?: string;
  read: boolean;
}

interface NotificationContextProps {
  notifications: AppNotification[];
  addManualNotification: (title: string, body: string, type: AppNotification['type'], senderName?: string) => void;
  clearAll: () => void;
  markAsRead: (id: string) => void;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  playNotificationSound: () => void;
  isHistoryOpen: boolean;
  setIsHistoryOpen: (open: boolean) => void;
}

const NotificationContext = createContext<NotificationContextProps | undefined>(undefined);

export function NotificationToastProvider({ 
  children, 
  user 
}: { 
  children: React.ReactNode; 
  user: UserData | null;
}) {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [activeToasts, setActiveToasts] = useState<AppNotification[]>([]);
  const [soundEnabled, setSoundEnabled] = useState(() => {
    return localStorage.getItem('school_app_sound_enabled') !== 'false';
  });
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  // Keep track of session start to avoid notifying backdated records
  const sessionStartTimeRef = useRef<Date>(new Date());

  // References for unsubscription
  const unsubscribeRefs = useRef<(() => void)[]>([]);

  // 1. Persist Sound Settings
  useEffect(() => {
    localStorage.setItem('school_app_sound_enabled', String(soundEnabled));
  }, [soundEnabled]);

  // 2. Play beautiful synthesized Web Audio chime (mobile haptic chime style)
  const playNotificationSound = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      // Chime note 1 (High, crisp, cheerful)
      const osc1 = audioCtx.createOscillator();
      const gain1 = audioCtx.createGain();
      
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
      gain1.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gain1.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);
      
      osc1.connect(gain1);
      gain1.connect(audioCtx.destination);
      osc1.start();
      osc1.stop(audioCtx.currentTime + 0.3);

      // Chime note 2 (Staggered slightly after note 1, higher pitch, creating a "ding-dong" / ping sound)
      setTimeout(() => {
        try {
          const osc2 = audioCtx.createOscillator();
          const gain2 = audioCtx.createGain();
          
          osc2.type = 'sine';
          osc2.frequency.setValueAtTime(1320, audioCtx.currentTime); // E6 note
          gain2.gain.setValueAtTime(0.08, audioCtx.currentTime);
          gain2.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);
          
          osc2.connect(gain2);
          gain2.connect(audioCtx.destination);
          osc2.start();
          osc2.stop(audioCtx.currentTime + 0.3);
        } catch (_) {}
      }, 70);

    } catch (e) {
      console.warn("Web Audio API not supported or user interaction required:", e);
    }
  };

  // Helper to add notification and show toast
  const triggerNotification = (
    title: string, 
    body: string, 
    type: AppNotification['type'], 
    senderName?: string
  ) => {
    const newNotif: AppNotification = {
      id: `${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      title,
      body,
      type,
      timestamp: new Date(),
      senderName,
      read: false
    };

    setNotifications(prev => [newNotif, ...prev]);
    setActiveToasts(prev => [...prev, newNotif]);
    playNotificationSound();

    // Haptic pop feedback simulation on console or if browser vibration is allowed
    if ('vibrate' in navigator) {
      try {
        navigator.vibrate([40, 30, 40]);
      } catch (_) {}
    }

    // Auto-remove toast after 4 seconds
    setTimeout(() => {
      setActiveToasts(prev => prev.filter(t => t.id !== newNotif.id));
    }, 4500);
  };

  // Manual trigger interface
  const addManualNotification = (
    title: string, 
    body: string, 
    type: AppNotification['type'], 
    senderName?: string
  ) => {
    triggerNotification(title, body, type, senderName);
  };

  const clearAll = () => {
    setNotifications([]);
    setActiveToasts([]);
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  // 3. Real-time Listeners for Firestore Events
  useEffect(() => {
    if (!user || !user.username) {
      // Clear listeners
      unsubscribeRefs.current.forEach(unsub => unsub());
      unsubscribeRefs.current = [];
      return;
    }

    const sessionStart = sessionStartTimeRef.current;
    console.log("Setting up real-time notification loaders. Session start:", sessionStart);

    // -- A. CHAT SYSTEM MESSAGES LISTENER --
    // We listen to changes in chat rooms that the user is a member of.
    // When lastMessageAt is updated, and the sender is not the logged-in user, we notify!
    const roomQuery = query(
      collection(db, 'chat_rooms'),
      where('members', 'array-contains', user.username)
    );

    let isInitialRoomLoad = true;
    const unsubRooms = onSnapshot(roomQuery, (snapshot) => {
      // On first load, we don't notify of old messages, just update state.
      if (isInitialRoomLoad) {
        isInitialRoomLoad = false;
        return;
      }

      snapshot.docChanges().forEach(change => {
        if (change.type === 'modified') {
          const roomData = change.doc.data();
          const lastSender = roomData.lastSender || roomData.createdBy;
          if (lastSender && lastSender !== user.username) {
            triggerNotification(
              roomData.type === 'group' ? `💬 Групп чат: ${roomData.name}` : `💬 Шинэ чат (${roomData.lastSenderName || lastSender})`,
              roomData.lastMessage || 'Шинэ зурвас илгээлээ.',
              'chat',
              roomData.lastSenderName || lastSender
            );
          }
        }
      });
    }, (err) => console.error("Room notify snapshot error:", err));

    unsubscribeRefs.current.push(unsubRooms);

    // -- B. LESSONS SYSTEM LISTENER (For Academic Lessons, relevant for Students) --
    if (user.role === 'student') {
      let isInitialLessonLoad = true;
      const lessonsQuery = query(
        collection(db, 'lessons'),
        orderBy('createdAt', 'desc'),
        limit(5)
      );

      const unsubLessons = onSnapshot(lessonsQuery, (snapshot) => {
        if (isInitialLessonLoad) {
          isInitialLessonLoad = false;
          return;
        }

        snapshot.docChanges().forEach(change => {
          if (change.type === 'added') {
            const lessonData = change.doc.data();
            triggerNotification(
              `📚 Шинэ хичээл оруулав`,
              `Багш ${lessonData.teacherName || lessonData.teacher} нь "${lessonData.topic}" сэдэвтэй шинэ хичээл орууллаа.`,
              'lesson',
              lessonData.teacherName || lessonData.teacher
            );
          }
        });
      }, (err) => console.error("Lesson notify snapshot error:", err));

      unsubscribeRefs.current.push(unsubLessons);

      // -- C. ASSIGNMENTS LISTENER (For Homeworks, relevant for Students) --
      let isInitialAsgLoad = true;
      const asgQuery = query(
        collection(db, 'assignments'),
        orderBy('createdAt', 'desc'),
        limit(5)
      );

      const unsubAsg = onSnapshot(asgQuery, (snapshot) => {
        if (isInitialAsgLoad) {
          isInitialAsgLoad = false;
          return;
        }

        snapshot.docChanges().forEach(change => {
          if (change.type === 'added') {
            const asgData = change.doc.data();
            triggerNotification(
              `📝 Шинэ даалгавар`,
              `Багш ${asgData.teacherName || asgData.teacher} нь "${asgData.title}" даалгавар орууллаа.`,
              'assignment',
              asgData.teacherName || asgData.teacher
            );
          }
        });
      }, (err) => console.error("Assignment notify snapshot error:", err));

      unsubscribeRefs.current.push(unsubAsg);

      // -- D. GRADES LISTENER (For Grades release, relevant for Students) --
      let isInitialGradesLoad = true;
      const gradesQuery = query(
        collection(db, 'grades'),
        where('studentUsername', '==', user.username)
      );

      const unsubGrades = onSnapshot(gradesQuery, (snapshot) => {
        if (isInitialGradesLoad) {
          isInitialGradesLoad = false;
          return;
        }

        snapshot.docChanges().forEach(change => {
          if (change.type === 'added' || change.type === 'modified') {
            const gradeData = change.doc.data();
            triggerNotification(
              `⭐ Шинэ үнэлгээ орлоо`,
              `Танд "${gradeData.assignmentTitle}" даалгаварт ${gradeData.grade} дүн тавигдлаа.`,
              'grade'
            );
          }
        });
      }, (err) => console.error("Grade notify snapshot error:", err));

      unsubscribeRefs.current.push(unsubGrades);
    } else if (user.role === 'teacher') {
      // -- E. STUDENT SUBMISSIONS LISTENER (For Homework Submissions, relevant for Teachers) --
      let isInitialSubsLoad = true;
      const subsQuery = query(
        collection(db, 'student_submissions'),
        where('teacher', '==', user.username),
        limit(5)
      );

      const unsubSubs = onSnapshot(subsQuery, (snapshot) => {
        if (isInitialSubsLoad) {
          isInitialSubsLoad = false;
          return;
        }

        snapshot.docChanges().forEach(change => {
          if (change.type === 'added') {
            const subData = change.doc.data();
            triggerNotification(
              `📥 Оюутны материал илгээв`,
              `${subData.studentRealName || subData.studentUsername} нь "${subData.assignmentTitle}" даалгаврын хариуг илгээлээ.`,
              'assignment',
              subData.studentRealName || subData.studentUsername
            );
          }
        });
      }, (err) => console.error("Submissions notify snapshot error:", err));

      unsubscribeRefs.current.push(unsubSubs);
    }

    return () => {
      unsubscribeRefs.current.forEach(unsub => unsub());
      unsubscribeRefs.current = [];
    };
  }, [user?.username, user?.role]);

  // Render proper icon based on notification type
  const getNotificationIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'chat':
        return <div className="p-2.5 bg-blue-500 text-white rounded-full"><MessageSquare size={18} /></div>;
      case 'lesson':
        return <div className="p-2.5 bg-teal-500 text-white rounded-full"><FileText size={18} /></div>;
      case 'assignment':
        return <div className="p-2.5 bg-indigo-500 text-white rounded-full"><CheckCircle size={18} /></div>;
      case 'grade':
        return <div className="p-2.5 bg-amber-500 text-white rounded-full"><Star size={18} /></div>;
      case 'award':
        return <div className="p-2.5 bg-fuchsia-500 text-white rounded-full"><Star size={18} className="animate-spin" /></div>;
      default:
        return <div className="p-2.5 bg-slate-500 text-white rounded-full"><Bell size={18} /></div>;
    }
  };

  return (
    <NotificationContext.Provider value={{
      notifications,
      addManualNotification,
      clearAll,
      markAsRead,
      soundEnabled,
      setSoundEnabled,
      playNotificationSound,
      isHistoryOpen,
      setIsHistoryOpen
    }}>
      {children}

      {/* --- IN-APP BANNER IN iOS / ANDROID PUSH STYLE --- */}
      <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-[9999] flex flex-col gap-2.5 w-[90%] max-w-[420px] pointer-events-none select-none">
        <AnimatePresence>
          {activeToasts.map((toast) => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: -65, scale: 0.92 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -40, scale: 0.95 }}
              transition={{ type: 'spring', damping: 15, stiffness: 180 }}
              className="pointer-events-auto bg-slate-900/90 dark:bg-slate-950/95 backdrop-blur-xl border border-slate-800/80 rounded-3xl p-4 shadow-[0_15px_30px_rgb(0,0,0,0.35)] flex items-start gap-3.5 relative overflow-hidden"
            >
              {/* iOS-Style App Identity indicator bar */}
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 opacity-90" />
              
              <div className="flex-shrink-0 mt-1">
                {getNotificationIcon(toast.type)}
              </div>
              
              <div className="flex-1 min-w-0 pr-4">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="text-[10px] sm:text-xs font-black text-indigo-400 uppercase tracking-widest flex items-center gap-1">
                    <Smartphone size={11} />
                    Сургуулийн систем
                  </span>
                  <span className="text-[9px] text-slate-500 font-bold">• Дөнгөж сая</span>
                </div>
                <h4 className="text-sm font-extrabold text-white truncate leading-tight select-text">{toast.title}</h4>
                <p 
                  className="text-xs text-slate-350 font-normal leading-snug mt-1 max-h-[50px] overflow-hidden select-text"
                  dangerouslySetInnerHTML={{ __html: toast.body }}
                />
              </div>

              <button
                type="button"
                onClick={() => {
                  setActiveToasts(prev => prev.filter(t => t.id !== toast.id));
                  markAsRead(toast.id);
                }}
                className="flex-shrink-0 text-slate-500 hover:text-white p-1 rounded-full hover:bg-slate-800 transition-colors cursor-pointer self-start"
              >
                <X size={16} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* --- RECENT NOTIFICATION CENTER DRAWER --- */}
      <AnimatePresence>
        {isHistoryOpen && (
          <div className="fixed inset-0 z-[2000] select-none">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsHistoryOpen(false)}
              className="absolute inset-0 bg-slate-950/50 backdrop-blur-xs cursor-pointer"
            />
            {/* Drawer */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className="absolute top-0 right-0 bottom-0 w-full max-w-sm bg-white dark:bg-slate-900 border-l border-slate-200/50 dark:border-slate-850 shadow-2xl flex flex-col p-6 pointer-events-auto"
            >
              <div className="flex justify-between items-center pb-4 border-b border-slate-100 dark:border-slate-800/80">
                <div>
                  <h3 className="text-lg font-black text-slate-800 dark:text-white flex items-center gap-2">
                    <Bell size={18} className="text-indigo-500 animate-swing" />
                    Мэдэгдлийн төв
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">Сургуулийн идэвхтэй сонордуулга</p>
                </div>
                <button
                  onClick={() => setIsHistoryOpen(false)}
                  className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Preferences inside history */}
              <div className="py-3.5 px-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-800/40 my-4 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Сонордуулгын дуу</span>
                <button
                  type="button"
                  onClick={() => {
                    setSoundEnabled(!soundEnabled);
                    if (!soundEnabled) {
                      setTimeout(() => playNotificationSound(), 100);
                    }
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    soundEnabled 
                      ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-500/20' 
                      : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 border border-slate-200/60 dark:border-slate-700'
                  }`}
                >
                  {soundEnabled ? <Volume2 size={14} /> : <VolumeX size={14} />}
                  {soundEnabled ? 'Идэвхтэй' : 'Хаасан'}
                </button>
              </div>

              {/* Notification Lists */}
              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                {notifications.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8">
                    <div className="w-16 h-16 rounded-full bg-slate-50 dark:bg-slate-800/60 flex items-center justify-center text-slate-350 dark:text-slate-600 mb-4 animate-pulse">
                      <Bell size={28} />
                    </div>
                    <p className="text-sm font-bold text-slate-400">Сонордуулга байхгүй байна</p>
                    <p className="text-xs text-slate-500 mt-1">Чат зурвас, шинэ хичээл, дүн зэрэг энд цаг тухайд нь харагдана.</p>
                  </div>
                ) : (
                  notifications.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => markAsRead(n.id)}
                      className={`p-3.5 rounded-2xl border text-left cursor-pointer transition-all ${
                        n.read 
                          ? 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800/60 opacity-75 hover:bg-slate-50 dark:hover:bg-slate-800/40' 
                          : 'bg-slate-50 dark:bg-slate-800 border-indigo-100/55 dark:border-indigo-950 hover:bg-indigo-50/20 dark:hover:bg-slate-750'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="scale-90 mt-0.5">{getNotificationIcon(n.type)}</div>
                        <div className="flex-1 min-w-0">
                          <h5 className="text-xs font-black text-slate-850 dark:text-white truncate leading-tight">{n.title}</h5>
                          <p 
                            className="text-[11px] text-slate-500 dark:text-slate-350 mt-1 leading-relaxed line-clamp-2 select-text"
                            dangerouslySetInnerHTML={{ __html: n.body }}
                          />
                          <p className="text-[10px] text-slate-400 font-bold mt-1.5 flex justify-between items-center">
                            <span>{n.senderName || 'Систем'}</span>
                            <span>{new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {notifications.length > 0 && (
                <button
                  type="button"
                  onClick={clearAll}
                  className="w-full text-center py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl font-bold text-xs mt-4 cursor-pointer transition-colors"
                >
                  Бүгдийг устгах
                </button>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationToastProvider');
  }
  return context;
}
