import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Smartphone, Download, HelpCircle, X, ChevronRight, CheckCircle, Monitor, Chrome, Apple } from 'lucide-react';

interface PWAInstallGuideProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PWAInstallGuide({ isOpen, onClose }: PWAInstallGuideProps) {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [activeTab, setActiveTab] = useState<'android' | 'ios' | 'pc'>('android');

  useEffect(() => {
    // Detect if device is iOS
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    if (isIOS) {
      setActiveTab('ios');
    }

    const handler = (e: Event) => {
      // Prevent Chrome 67 and earlier from automatically showing the prompt
      e.preventDefault();
      // Stash the event so it can be triggered later.
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handler);

    // If already in standalone mode, hide
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstallable(false);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    
    // Show the native install prompt
    deferredPrompt.prompt();
    
    // Wait for the user to respond to the prompt
    const { outcome } = await deferredPrompt.userChoice;
    console.log(`User responded to the install prompt: ${outcome}`);
    
    // We've used the prompt, and can't use it again
    setDeferredPrompt(null);
    setIsInstallable(false);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[10000] select-none flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-950/60 backdrop-blur-md cursor-pointer"
          />

          {/* Dialog */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0, y: 15 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 15 }}
            className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-[2.5rem] w-full max-w-lg shadow-[0_25px_60px_rgb(0,0,0,0.3)] pointer-events-auto overflow-hidden relative flex flex-col max-h-[90vh]"
          >
            {/* Elegant Header */}
            <div className="p-6 pb-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-850/50">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-indigo-600 text-white rounded-2xl shadow-md">
                  <Smartphone size={22} className="animate-pulse" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-800 dark:text-white uppercase tracking-wider">Гар утсанд суулгах</h3>
                  <p className="text-[11px] text-slate-500 font-bold uppercase tracking-wider">Progressive Web App (PWA)</p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-white cursor-pointer transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Content Tabs */}
            <div className="flex border-b border-slate-100 dark:border-slate-800 bg-slate-50/20 dark:bg-slate-850/20 p-2 gap-1">
              <button
                type="button"
                onClick={() => setActiveTab('android')}
                className={`flex-1 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'android'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-500 dark:text-slate-400 hover:bg-slate-155 dark:hover:bg-slate-800'
                }`}
              >
                <Chrome size={15} />
                Android / Chrome
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('ios')}
                className={`flex-1 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'ios'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-500 dark:text-slate-400 hover:bg-slate-155 dark:hover:bg-slate-800'
                }`}
              >
                <Apple size={15} />
                iPhone / iOS Safari
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('pc')}
                className={`flex-1 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'pc'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-500 dark:text-slate-400 hover:bg-slate-155 dark:hover:bg-slate-800'
                }`}
              >
                <Monitor size={15} />
                Компьютер / PC
              </button>
            </div>

            {/* Instruction Body */}
            <div className="p-6 overflow-y-auto flex-1 space-y-4">
              {/* Direct Native Installation Trigger Banner if supported */}
              {deferredPrompt && (
                <div className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/25 dark:to-teal-950/25 p-4 rounded-3xl border border-emerald-100 dark:border-emerald-900/40 flex items-center justify-between gap-4 animate-in fade-in duration-300">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-emerald-500 text-white rounded-2xl mt-0.5"><Download size={16} /></div>
                    <div>
                      <h4 className="text-xs font-extrabold text-emerald-950 dark:text-emerald-300">Шууд суулгах боломжтой</h4>
                      <p className="text-[11px] text-emerald-800 dark:text-emerald-400 mt-0.5">Та доорх товчийг даран аппликейшнийг гар утсандаа шууд суулгаж болно.</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleInstallClick}
                    className="shrink-0 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-xs font-black shadow-sm transition-colors cursor-pointer"
                  >
                    Апп суулгах 📱
                  </button>
                </div>
              )}

              {/* Tab Specific Content */}
              {activeTab === 'android' && (
                <div className="space-y-3.5">
                  <p className="text-xs text-slate-500 font-medium">АНДРОИД утсан дээр Chrome ашиглан суулгах заавар:</p>
                  
                  <div className="space-y-3">
                    <div className="flex items-start gap-4">
                      <div className="w-6 h-6 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 rounded-full flex items-center justify-center font-mono font-black text-xs shrink-0 mt-0.5">1</div>
                      <div>
                        <h4 className="text-xs font-black text-slate-800 dark:text-slate-200">Баруун дээд хэсгийн цэс сонгох</h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">Chrome хөтчийн баруун дээд буланд байрлах 3 цэг (<strong className="text-slate-800 dark:text-slate-300">⋮</strong>) дээр дарна уу.</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-6 h-6 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 rounded-full flex items-center justify-center font-mono font-black text-xs shrink-0 mt-0.5">2</div>
                      <div>
                        <h4 className="text-xs font-black text-slate-800 dark:text-slate-200">"Дэлгэцэнд нэмэх" дээр дарах</h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">Цэс дотроос <strong className="text-indigo-600 dark:text-indigo-400">"Апп суулгах" (Install app)</strong> эсвэл <strong className="text-slate-800 dark:text-slate-350">"Үндсэн дэлгэцэнд нэмэх" (Add to Home screen)</strong> гэсэн сонголтыг сонгоно уу.</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-6 h-6 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 rounded-full flex items-center justify-center font-mono font-black text-xs shrink-0 mt-0.5">3</div>
                      <div>
                        <h4 className="text-xs font-black text-slate-800 dark:text-slate-200">Батлах үйлдэл хийх</h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">Гарч ирэх цонхонд "Суулгах" эсвэл "Нэмэх" дээр дарж баталгаажуулснаар утасны дэлгэц дээр 4-р сургуулийн аппликейшн шууд татагдан олно.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'ios' && (
                <div className="space-y-3.5">
                  <p className="text-xs text-slate-500 font-medium">iPHONE утсан дээр Safari ашиглан суулгах заавар:</p>
                  
                  <div className="space-y-3 border border-indigo-100/60 dark:border-indigo-950/60 rounded-3xl p-4 bg-indigo-50/10 dark:bg-indigo-950/10">
                    <div className="flex items-start gap-4">
                      <div className="w-6 h-6 bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 rounded-full flex items-center justify-center font-mono font-black text-xs shrink-0 mt-0.5">1</div>
                      <div>
                        <h4 className="text-xs font-black text-slate-800 dark:text-slate-200">"Share" (Хуваалцах) товчийг дарах</h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">Safari хөтчийн доод талд байрлах хуваалцах тэмдэглэгээ буюу сумтай дөрвөлжин (<strong className="text-indigo-600 dark:text-indigo-400 font-serif">⬆️ / 📥</strong>) дээр дарна уу.</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-6 h-6 bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 rounded-full flex items-center justify-center font-mono font-black text-xs shrink-0 mt-0.5">2</div>
                      <div>
                        <h4 className="text-xs font-black text-slate-800 dark:text-slate-200">"Add to Home Screen"-ийг сонгох</h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">Нээгдэх цэснээс доош гүйлгэж цэхийг заагаад <strong className="text-indigo-600 dark:text-indigo-400">"Хувийн дэлгэцэнд нэмэх" (Add to Home Screen)</strong> дээр дарна уу.</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-6 h-6 bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 rounded-full flex items-center justify-center font-mono font-black text-xs shrink-0 mt-0.5">3</div>
                      <div>
                        <h4 className="text-xs font-black text-slate-800 dark:text-slate-200">"Add" / "Нэмэх" дээр дарах</h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">Баруун дээд буланд байх "Нэмэх" (Add) дээр дарснаар үйлдэл дуусна.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'pc' && (
                <div className="space-y-3.5">
                  <p className="text-xs text-slate-500 font-medium">Компьютер / Laptop дээр аппликейшн байдлаар суулгах:</p>
                  
                  <div className="space-y-3">
                    <div className="flex items-start gap-4">
                      <div className="w-6 h-6 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 rounded-full flex items-center justify-center font-mono font-black text-xs shrink-0 mt-0.5">1</div>
                      <div>
                        <h4 className="text-xs font-black text-slate-800 dark:text-slate-200">Хаягийн мөрөн дэх дүрсийг олох</h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">Chrome/Edge хөтчийн дээд талын URL хаяг бичих хэсгийн баруун талд байрлах <strong className="text-indigo-600 dark:text-indigo-400">Апп суулгах (Install application)</strong> буюу компьютерын зурагтай тэмдэг олно уу.</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-6 h-6 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 rounded-full flex items-center justify-center font-mono font-black text-xs shrink-0 mt-0.5">2</div>
                      <div>
                        <h4 className="text-xs font-black text-slate-800 dark:text-slate-200">Суулгах цонхыг баталгаажуулна</h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">Цэсийг сонгоод гарч ирэх <strong className="text-slate-800 dark:text-slate-300">"Install"</strong> эсвэл <strong className="text-slate-800 dark:text-slate-300">"Суулгах"</strong> товчлуур дээр дарна уу.</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-6 h-6 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 rounded-full flex items-center justify-center font-mono font-black text-xs shrink-0 mt-0.5">3</div>
                      <div>
                        <h4 className="text-xs font-black text-slate-800 dark:text-slate-200">Desktop апп бэлэн болно</h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">Аппликейшн таны компьютер дээр бие даасан байдлаар нээгдэх бөгөөд таны дэлгэц болон Taskbar дээр дүрс нь нэмэгдэнэ.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Sticky bottom CTA panel */}
            <div className="p-6 bg-slate-50 dark:bg-slate-850 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle size={15} className="text-emerald-500 shrink-0" />
                <span className="text-[10px] sm:text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-wide">Үнэгүй, аюулгүй, хянах систем</span>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl text-xs font-black shadow-md hover:shadow-lg transition-all cursor-pointer"
              >
                Ойлголоо
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
